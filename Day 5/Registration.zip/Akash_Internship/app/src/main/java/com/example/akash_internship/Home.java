package com.example.akash_internship;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Home extends AppCompatActivity {
    String Name, Email, Password, MobileNo, Gender, Hobby1, Hobby2, Hobby3, Hobby4;
    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        text=findViewById(R.id.text);

        Intent i = getIntent();
        Name = i.getStringExtra("name");
        Email = i.getStringExtra("email");
        Password = i.getStringExtra("password");
        Gender = i.getStringExtra("gender");
        MobileNo = i.getStringExtra("mobileNo");
        Hobby1 = i.getStringExtra("hobby1");
        Hobby2 = i.getStringExtra("hobby2");
        Hobby3 = i.getStringExtra("hobby3");
        Hobby4 = i.getStringExtra("hobby4");

        text.setText(Name+""+Email+""+Password+""+Gender+""+MobileNo+""+Hobby1+""+Hobby2+""+Hobby3+""+""+Hobby4);

    }
}